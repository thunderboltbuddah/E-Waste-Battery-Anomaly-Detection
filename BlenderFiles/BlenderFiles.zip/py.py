import bpy
import random
import os
import csv
import math
from bpy_extras.object_utils import world_to_camera_view

# ==================== CONFIGURATION ====================
OUTPUT_FOLDER = "/content/drive/MyDrive/Battery_Dataset/"
TOTAL_IMAGES = 10000

BATTERIES = {
    "Battery_Normal": 0,
    "Battery_Swollen": 1
}

CLASS_WEIGHTS = {
    "Battery_Normal": 0.40,
    "Battery_Swollen": 0.60
}
# =======================================================

scene  = bpy.context.scene
camera = scene.camera

scene.render.resolution_x = 640
scene.render.resolution_y = 640
scene.render.resolution_percentage = 100

scene.use_nodes = True
scene.render.use_compositing = True


def setup_compositor_noise():
    tree = scene.node_tree
    tree.nodes.clear()

    rl   = tree.nodes.new('CompositorNodeRLayers')
    comp = tree.nodes.new('CompositorNodeComposite')
    rl.location   = (0,   300)
    comp.location = (750, 300)

    last_output = rl.outputs['Image']

    # Lens distortion — try Blender 4.x name first, fall back to 3.x
    lens = None
    for type_name in ('CompositorNodeLensDistortion', 'CompositorNodeLensDist'):
        try:
            lens = tree.nodes.new(type_name)
            break
        except RuntimeError:
            continue

    if lens:
        lens.location = (250, 300)
        lens.inputs['Distortion'].default_value = random.uniform(-0.03, 0.03)
        lens.inputs['Dispersion'].default_value = random.uniform(0.0,   0.02)
        tree.links.new(last_output, lens.inputs['Image'])
        last_output = lens.outputs['Image']

    # Motion blur
    scene.render.use_motion_blur        = random.random() > 0.4
    scene.render.motion_blur_shutter    = random.uniform(0.1, 0.8)

    # Atmospheric haze overlay
    try:
        mist = tree.nodes.new('CompositorNodeMixRGB')
        mist.location   = (500, 300)
        mist.blend_type = 'ADD'
        mist.inputs[0].default_value = random.uniform(0.0, 0.06)
        mist.inputs[2].default_value = (
            random.uniform(0.6, 0.9),
            random.uniform(0.6, 0.9),
            random.uniform(0.6, 0.9),
            1.0
        )
        tree.links.new(last_output,           mist.inputs[1])
        tree.links.new(mist.outputs['Image'], comp.inputs['Image'])
    except Exception:
        tree.links.new(last_output, comp.inputs['Image'])


def randomize_camera():
    """Top-down camera with safe gentle tilt — batteries stay in frame."""
    cam = camera
    cam.location.x = 0.0
    cam.location.y = 0.0
    cam.location.z = random.uniform(4.0, 6.0)

    # Gentle tilt only — max 10 degrees so batteries stay visible
    tilt = math.radians(random.uniform(0, 10))
    pan  = math.radians(random.uniform(0, 360))
    cam.rotation_euler.x = tilt
    cam.rotation_euler.y = 0.0
    cam.rotation_euler.z = pan

    camera.data.lens = random.uniform(30, 60)

    if camera.data.type == 'ORTHO':
        camera.data.ortho_scale = random.uniform(4.0, 7.0)

def setup_multi_lighting():
    for obj in list(scene.collection.objects):
        if obj.type == 'LIGHT':
            bpy.data.objects.remove(obj, do_unlink=True)

    # Pick a lighting scenario for this frame
    scenario = random.choice([
        'bright_factory',   # well lit, multiple lights
        'dim_factory',      # single weak overhead
        'side_lit',         # one strong side light, heavy shadows
        'backlit',          # light behind batteries, dark foreground
        'night_shift',      # very dark, one spotlight only
        'mixed',            # two lights, different colors and intensities
    ])

    if scenario == 'bright_factory':
        num_lights = random.randint(2, 4)
        energy_range = (600, 1500)
        z_range = (3, 5)

    elif scenario == 'dim_factory':
        num_lights = 1
        energy_range = (80, 250)
        z_range = (4, 6)

    elif scenario == 'side_lit':
        num_lights = 1
        energy_range = (400, 900)
        z_range = (2, 4)

    elif scenario == 'backlit':
        num_lights = random.randint(1, 2)
        energy_range = (300, 700)
        z_range = (1, 2.5)

    elif scenario == 'night_shift':
        num_lights = 1
        energy_range = (150, 400)
        z_range = (2, 5)

    else:  # mixed
        num_lights = 2
        energy_range = (200, 1200)
        z_range = (2, 6)

    for i in range(num_lights):
        light_type = random.choice(['SPOT', 'AREA', 'POINT'])
        light_data = bpy.data.lights.new(f"FactoryLight_{i}", type=light_type)
        light_obj  = bpy.data.objects.new(f"FactoryLight_{i}", light_data)
        scene.collection.objects.link(light_obj)

        # Side-lit and backlit get off-axis positions
        if scenario == 'side_lit':
            light_obj.location = (
                random.choice([-4, 4]),  # hard left or right
                random.uniform(-1, 1),
                random.uniform(z_range[0], z_range[1])
            )
            light_obj.rotation_euler.x = math.radians(random.uniform(30, 60))
        elif scenario == 'backlit':
            light_obj.location = (
                random.uniform(-2, 2),
                random.uniform(-4, -2),   # behind the batteries
                random.uniform(z_range[0], z_range[1])
            )
            light_obj.rotation_euler.x = math.radians(random.uniform(10, 40))
        else:
            light_obj.location = (
                random.uniform(-3, 3),
                random.uniform(-3, 3),
                random.uniform(z_range[0], z_range[1])
            )
            light_obj.rotation_euler.x = math.radians(random.uniform(70, 100))

        light_obj.rotation_euler.z = math.radians(random.uniform(0, 360))
        light_data.energy = random.uniform(energy_range[0], energy_range[1])

        color_type = random.choice(['warm', 'cool', 'neutral', 'harsh_white', 'orange_sodium'])
        if color_type == 'warm':
            light_data.color = (1.0, random.uniform(0.7, 0.9), random.uniform(0.4, 0.6))
        elif color_type == 'cool':
            light_data.color = (random.uniform(0.6, 0.85), random.uniform(0.85, 1.0), 1.0)
        elif color_type == 'harsh_white':
            light_data.color = (1.0, 1.0, 1.0)
        elif color_type == 'orange_sodium':
            # Sodium vapor lamps common in factories
            light_data.color = (1.0, random.uniform(0.45, 0.6), 0.0)
        else:
            light_data.color = (1.0, 1.0, 1.0)

        if light_type == 'SPOT':
            light_data.spot_size  = math.radians(random.uniform(15, 80))
            light_data.spot_blend = random.uniform(0.05, 0.6)

        # Night shift and dim always cast hard shadows
        if scenario in ('night_shift', 'dim_factory', 'side_lit'):
            light_data.use_shadow = True
        else:
            light_data.use_shadow = random.random() > 0.3

    # Shadow caster overhead
    if random.random() > 0.5:
        bpy.ops.mesh.primitive_plane_add(size=random.uniform(0.5, 2.0))
        shadow_obj = bpy.context.active_object
        shadow_obj.name = "ShadowCaster"
        shadow_obj.location = (
            random.uniform(-2, 2),
            random.uniform(-2, 2),
            random.uniform(1.5, 3.0)
        )
        shadow_obj.rotation_euler.z = math.radians(random.uniform(0, 360))
        shadow_obj.visible_camera  = False
        shadow_obj.visible_diffuse = False
        shadow_obj.visible_glossy  = False
        shadow_obj.visible_shadow  = True


def randomize_hdri():
    world = bpy.context.scene.world
    if not world or not world.use_nodes:
        return

    mapping_node = world.node_tree.nodes.get("Mapping")
    if mapping_node:
        mapping_node.inputs['Rotation'].default_value[2] = random.uniform(0, 6.28)

    bg_node = world.node_tree.nodes.get("Background")
    if bg_node:
        # Wide range: some frames nearly dark ambient, some bright
        scenario_roll = random.random()
        if scenario_roll < 0.25:
            # Very dark — night shift / poorly lit factory
            bg_node.inputs['Strength'].default_value = random.uniform(0.0, 0.15)
        elif scenario_roll < 0.55:
            # Dim but visible
            bg_node.inputs['Strength'].default_value = random.uniform(0.15, 0.5)
        elif scenario_roll < 0.80:
            # Normal factory lighting
            bg_node.inputs['Strength'].default_value = random.uniform(0.5, 1.0)
        else:
            # Overexposed / bright outdoor loading dock
            bg_node.inputs['Strength'].default_value = random.uniform(1.0, 2.5)


def randomize_swelling(obj):
    """
    Vary swelling severity via shape key if one exists on the mesh.
    If no shape key exists, applies a non-uniform scale bulge instead.
    """
    if obj.data.shape_keys and len(obj.data.shape_keys.key_blocks) > 1:
        # Use shape key index 1 (first deform key after Basis)
        key = obj.data.shape_keys.key_blocks[1]
        key.value = random.uniform(0.3, 1.0)
    else:
        # Fallback: non-uniform scale to simulate mild vs severe bulge
        bulge = random.uniform(1.0, 1.25)
        obj.scale.x *= bulge
        obj.scale.y *= bulge
        obj.scale.z *= random.uniform(0.95, 1.05)


def randomize_battery_size(obj, chosen_name):
    """
    Apply size ratios mimicking real battery form factors.
    AA, AAA, 18650, pouch — modelled as scale multipliers.
    """
    size_profiles = {
        'AA':    (1.0,  1.0,  1.0),
        'AAA':   (0.65, 0.65, 0.88),
        '18650': (1.1,  1.1,  2.3),
        'pouch': (1.8,  0.4,  1.2),
    }
    profile = random.choice(list(size_profiles.values()))
    obj.scale.x *= profile[0]
    obj.scale.y *= profile[1]
    obj.scale.z *= profile[2]


def weighted_battery_choice():
    names   = list(CLASS_WEIGHTS.keys())
    weights = [CLASS_WEIGHTS[n] for n in names]
    return random.choices(names, weights=weights, k=1)[0]


def get_bounding_box(obj, cam, scn):
    mat_world = obj.matrix_world
    mesh      = obj.data
    x_coords, y_coords = [], []
    for vert in mesh.vertices:
        world_coord  = mat_world @ vert.co
        camera_coord = world_to_camera_view(scn, cam, world_coord)
        x_coords.append(camera_coord.x)
        y_coords.append(camera_coord.y)
    if not x_coords:
        return 0, 0, 0, 0
    min_x = max(0.0, min(x_coords))
    max_x = min(1.0, max(x_coords))
    min_y = max(0.0, min(y_coords))
    max_y = min(1.0, max(y_coords))
    return min_x, min_y, max_x, max_y


def boxes_overlap(a, b, margin=0.02):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    return not (ax2 + margin < bx1 or bx2 + margin < ax1 or
                ay2 + margin < by1 or by2 + margin < ay1)


def screen_to_world_z_plane(cam_obj, screen_x, screen_y, target_z=0.02):
    cam_data = cam_obj.data
    if cam_data.type == 'ORTHO':
        scale_factor = cam_data.ortho_scale * 0.5
    else:
        scale_factor = cam_obj.location.z * math.tan(
            math.radians(cam_data.angle * 0.5 * (180 / math.pi))
        ) * 0.9
    world_x = (screen_x - 0.5) * scale_factor * 2.0
    world_y = (screen_y - 0.5) * scale_factor * 2.0
    return world_x, world_y, target_z


def reset_all_batteries():
    for name in BATTERIES.keys():
        obj = bpy.data.objects.get(name)
        if obj:
            obj.hide_render   = True
            obj.hide_viewport = True


def randomize_belt_surface():
    bg_mat = bpy.data.materials.get("BackgroundMaterial")
    if not bg_mat:
        return

    belt_style = random.choice(['black_rubber', 'dark_gray', 'worn_tan'])
    if belt_style == 'black_rubber':
        r = random.uniform(0.02, 0.08)
        g = random.uniform(0.02, 0.08)
        b = random.uniform(0.02, 0.08)
    elif belt_style == 'dark_gray':
        v = random.uniform(0.1, 0.25)
        r, g, b = v, v, v
    else:
        r = random.uniform(0.3, 0.5)
        g = random.uniform(0.25, 0.4)
        b = random.uniform(0.1, 0.2)

    rgba = (r, g, b, 1.0)
    bg_mat.diffuse_color = rgba
    if bg_mat.use_nodes and bg_mat.node_tree:
        for node in bg_mat.node_tree.nodes:
            if node.type == 'BSDF_PRINCIPLED':
                node.inputs['Base Color'].default_value = rgba
                node.inputs['Roughness'].default_value  = random.uniform(0.6, 1.0)
                node.inputs['Metallic'].default_value   = 0.0
                break




def write_yolo_label(label_folder, base_filename, annotations):
    """
    Write a YOLO format .txt file alongside each render.
    Each line: class_id cx cy w h  (all normalized 0-1)
    """
    txt_name = os.path.splitext(base_filename)[0] + ".txt"
    txt_path = os.path.join(label_folder, txt_name)
    with open(txt_path, 'w') as f:
        for (class_id, xmin, ymin, xmax, ymax) in annotations:
            cx = (xmin + xmax) / 2.0
            cy = (ymin + ymax) / 2.0
            w  = xmax - xmin
            h  = ymax - ymin
            # YOLO y-axis is flipped relative to Blender screen space
            cy_yolo = 1.0 - cy
            f.write(f"{class_id} {cx:.6f} {cy_yolo:.6f} {w:.6f} {h:.6f}\n")


# ==================== MAIN SETUP ====================
if not os.path.exists(OUTPUT_FOLDER):
    os.makedirs(OUTPUT_FOLDER)

# Separate folders for images and labels (standard YOLO structure)
IMAGE_FOLDER = os.path.join(OUTPUT_FOLDER, "images")
LABEL_FOLDER = os.path.join(OUTPUT_FOLDER, "labels")
os.makedirs(IMAGE_FOLDER, exist_ok=True)
os.makedirs(LABEL_FOLDER, exist_ok=True)

# Keep CSV as well for reference
csv_path   = os.path.join(OUTPUT_FOLDER, "dataset_labels.csv")
csv_file   = open(csv_path, mode='w', newline='')
csv_writer = csv.writer(csv_file)
csv_writer.writerow(["image_name", "class_id", "xmin", "ymin", "xmax", "ymax"])

reset_all_batteries()
print("--- STARTING DATASET GENERATION ---")

for i in range(TOTAL_IMAGES):
    base_filename = f"battery_frame_{i:04d}.png"
    placed_boxes  = []
    frame_annotations = []

    randomize_camera()
    setup_multi_lighting()
    randomize_belt_surface()
    randomize_hdri()
    setup_compositor_noise()

    if random.random() >= 0.10:
        num_batteries = random.randint(1, 4)

        screen_quadrants = [
            (0.25, 0.25),
            (0.75, 0.25),
            (0.25, 0.75),
            (0.75, 0.75)
        ]
        random.shuffle(screen_quadrants)

        for b in range(num_batteries):
            chosen_name  = weighted_battery_choice()
            class_id     = BATTERIES[chosen_name]
            is_swollen   = (chosen_name == "Battery_Swollen")
            original_obj = bpy.data.objects.get(chosen_name)
            if not original_obj:
                continue

            scr_x_base, scr_y_base = screen_quadrants[b]

            new_obj      = original_obj.copy()
            new_obj.data = original_obj.data.copy()
            scene.collection.objects.link(new_obj)
            new_obj.hide_render   = False
            new_obj.hide_viewport = False

            bpy.context.view_layer.objects.active = new_obj
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')

         

            # Vary swelling severity on swollen batteries
            if is_swollen:
                randomize_swelling(new_obj)

            # Apply battery size profile
            randomize_battery_size(new_obj, chosen_name)

            placed = False
            for attempt in range(8):
                scr_x = scr_x_base + random.uniform(-0.03, 0.03)
                scr_y = scr_y_base + random.uniform(-0.03, 0.03)

                target_x, target_y, target_z = screen_to_world_z_plane(
                    camera, scr_x, scr_y
                )
                new_obj.location.x = target_x
                new_obj.location.y = target_y
                new_obj.location.z = random.uniform(0.01, 0.03)

                if random.random() < 0.70:
                    new_obj.rotation_euler.x = math.radians(random.uniform(-15, 15))
                    new_obj.rotation_euler.y = math.radians(random.uniform(-15, 15))
                    new_obj.rotation_euler.z = random.uniform(0, 6.28)
                else:
                    new_obj.rotation_euler.x = random.uniform(0, 6.28)
                    new_obj.rotation_euler.y = random.uniform(0, 6.28)
                    new_obj.rotation_euler.z = random.uniform(0, 6.28)

                bpy.context.view_layer.update()

                xmin, ymin, xmax, ymax = get_bounding_box(new_obj, camera, scene)
                candidate = (xmin, ymin, xmax, ymax)
                valid = (xmax - xmin) > 0.01 and (ymax - ymin) > 0.01

                if valid and not any(boxes_overlap(candidate, pb) for pb in placed_boxes):
                    placed_boxes.append(candidate)
                    frame_annotations.append((class_id, xmin, ymin, xmax, ymax))
                    csv_writer.writerow([
                        base_filename, class_id,
                        f"{xmin:.4f}", f"{ymin:.4f}",
                        f"{xmax:.4f}", f"{ymax:.4f}"
                    ])
                    placed = True
                    break

            if not placed:
                bpy.data.objects.remove(new_obj, do_unlink=True)
                print(f"[frame {i}] slot {b} skipped — no valid position found")

    # Write YOLO .txt label file
    write_yolo_label(LABEL_FOLDER, base_filename, frame_annotations)

    bpy.context.view_layer.update()

    scene.render.filepath = os.path.join(IMAGE_FOLDER, base_filename)
    bpy.ops.render.render(write_still=True)

    # Cleanup battery clones
    for obj in list(scene.collection.objects):
        if "Battery_Normal." in obj.name or "Battery_Swollen." in obj.name:
            bpy.data.objects.remove(obj, do_unlink=True)

    # Cleanup lights
    for obj in list(scene.collection.objects):
        if obj.name.startswith("FactoryLight_"):
            bpy.data.objects.remove(obj, do_unlink=True)

    # Cleanup shadow casters
    for obj in list(scene.collection.objects):
        if obj.name == "ShadowCaster":
            bpy.data.objects.remove(obj, do_unlink=True)

    reset_all_batteries()

    if i % 50 == 0:
        print(f"[{i}/{TOTAL_IMAGES}] frames complete")

csv_file.close()
print("--- DATASET GENERATION COMPLETE ---")